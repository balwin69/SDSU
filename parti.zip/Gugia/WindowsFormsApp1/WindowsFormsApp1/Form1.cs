﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public bool buttonClick = false;
        public int UInput;
        public int fixedNum;
        public int guessCounter=0;
        

        public Form1()
        {
            InitializeComponent();
            
            Random random = new Random();
            fixedNum=random.Next(0,100);
            
          
     

    }

    private void textBox1_TextChanged(object sender, EventArgs e)
        {

          



        }

        private void button1_Click(object sender, EventArgs e)
        {
         
            int generatedNum = fixedNum;
            buttonClick = true;
            //string userInput=textBox1.Text;
            while (buttonClick == true)
            {

                try //try catchit vhandlavt tu sheiyvana integeris magivrad sxva rame
                {
                    UInput = Int32.Parse(textBox1.Text);
                    if (UInput >= 0 && UInput <= 100)// tu sheyvanili inputi 0 idan 100amde da ufro meti an naklebi
                    {
                        if (generatedNum == UInput)
                        {
                            MessageBox.Show("Correct");
                            buttonClick = false;
                            guessCounter = 0;
                            label3.Text = "Number of Tries: " + guessCounter;
                            Random random = new Random();
                            fixedNum = random.Next(0, 100);
                       
                        }
                        else if (generatedNum >= UInput)
                        {
                            MessageBox.Show("Your Number is Low");
                            buttonClick = false;
                            guessCounter++;
                            label3.Text = "Number of Tries: " + guessCounter;
                        }
                        else if(generatedNum <= UInput)
                        {
                            MessageBox.Show("Your Number is High");
                            buttonClick = false;
                            guessCounter++;
                            label3.Text = "Number of Tries: " + guessCounter;
                        }
                    }
                    else
                    {
                        string error = "Error: Must be Withing 0 and 100";
                        MessageBox.Show(error);
                        buttonClick = false;
                    }
                }
                catch
                {
                    MessageBox.Show("Error: Must be Integer");
                    buttonClick = false;
                }
            }
        }

     
    }
}
